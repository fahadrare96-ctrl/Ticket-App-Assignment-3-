import { useEffect, useState } from "react";
import {
  FlatList,
  SafeAreaView,
  StyleSheet,
  Text, TextInput,
  View
} from "react-native";

// ✅ Same local database
const moviesDB = [
  { id: "1", title: "Dune: Part Two",        genre: "Sci-Fi",    releaseDate: "2024-03-01", rating: 4.8 },
  { id: "2", title: "Inside Out 2",          genre: "Animation", releaseDate: "2024-06-14", rating: 4.7 },
  { id: "3", title: "Deadpool & Wolverine",  genre: "Action",    releaseDate: "2024-07-26", rating: 4.6 },
  { id: "4", title: "Alien: Romulus",        genre: "Horror",    releaseDate: "2024-08-16", rating: 4.3 },
  { id: "5", title: "Twisters",              genre: "Thriller",  releaseDate: "2024-07-19", rating: 4.1 },
  { id: "6", title: "The Wild Robot",        genre: "Animation", releaseDate: "2024-09-27", rating: 4.9 },
];

export default function HomeScreen() {
  const [query, setQuery]   = useState("");
  const [movies, setMovies] = useState(moviesDB);

  useEffect(() => {
    const filtered = moviesDB.filter((movie) =>
      movie.title.toLowerCase().includes(query.toLowerCase())
    );
    setMovies(filtered);
  }, [query]);

  // ✅ In React Native, FlatList replaces .map()
  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.poster}>
        <Text style={{ fontSize: 22 }}>🎥</Text>
      </View>
      <View style={styles.info}>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.genre}>{item.genre}</Text>
        <Text style={styles.date}>📅 {item.releaseDate}</Text>
        <Text style={styles.rating}>⭐ {item.rating}/5</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.heading}>🎬 CineBook</Text>

      {/* ✅ Search bar */}
      <TextInput
        placeholder="Search movies..."
        value={query}
        onChangeText={(text) => setQuery(text)} // 👈 React Native uses onChangeText
        style={styles.searchBar}
      />

      {/* ✅ FlatList renders the filtered movies efficiently */}
      <FlatList
        data={movies}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        ListEmptyComponent={<Text style={{ textAlign: "center", color: "#888" }}>No results.</Text>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container:  { flex: 1, padding: 20, backgroundColor: "#f9f9f9" },
  heading:    { fontSize: 26, fontWeight: "600", marginBottom: 16 },
  searchBar:  { backgroundColor: "#fff", borderWidth: 1, borderColor: "#ddd",
                borderRadius: 10, padding: 10, fontSize: 15, marginBottom: 16 },
  card:       { flexDirection: "row", backgroundColor: "#fff", borderRadius: 12,
                padding: 14, marginBottom: 10, gap: 12 },
  poster:     { width: 54, height: 80, backgroundColor: "#f0f0f0", borderRadius: 8,
                alignItems: "center", justifyContent: "center" },
  info:       { flex: 1 },
  title:      { fontSize: 16, fontWeight: "600", marginBottom: 4 },
  genre:      { fontSize: 12, color: "#666", marginBottom: 4 },
  date:       { fontSize: 12, color: "#888" },
  rating:     { fontSize: 12, color: "#f59e0b", marginTop: 4 },
});